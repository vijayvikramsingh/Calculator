//
//  TrigFuncCalculation.h
//  TrigFuncCalculation
//
//  Created by vijay singh on 7/13/21.
//

#import <Foundation/Foundation.h>

//! Project version number for TrigFuncCalculation.
FOUNDATION_EXPORT double TrigFuncCalculationVersionNumber;

//! Project version string for TrigFuncCalculation.
FOUNDATION_EXPORT const unsigned char TrigFuncCalculationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TrigFuncCalculation/PublicHeader.h>


