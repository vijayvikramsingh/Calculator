//
//  TrigFuncCalculation.swift
//  TrigFuncCalculation
//
//  Created by vijay singh on 7/13/21.
//

import Foundation

public struct TrigFuncCalculation {
    
    public init() {
        
    }
    
    public func signFunc(_ num: Double) -> Double {
        return sin(num * Double.pi / 180)
    }

    public func cosFunc(_ num: Double) -> Double {
        return cos(num * Double.pi / 180)
    }

    public func tanFunc(_ num: Double) -> Double {
        return tan(num * Double.pi / 180)
    }
}
