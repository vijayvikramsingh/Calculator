//
//  CalculatorViewController.swift
//  CalculatorUI
//
//  Created by vijay singh on 7/13/21.
//

import UIKit

public enum TrigSymbols {
    case Sin, Cos, Tan
}

public enum TwoDSymbols {
    case Square, Root, Log, Loge, Reverse
}

public protocol MathEvaluation: AnyObject {
    func evaluateSimpleMathFunction(number: String, symbol: Character)->String?
    func evaluateTrigFunction(number: String, symbol: Character, trigSymbol: TrigSymbols)->String?
    func evaluateTwoDFunction(number: String, symbol: Character, twoDSymbol: TwoDSymbols)->String?
}

public class CalculatorViewController: UIViewController {

    @IBOutlet weak var displayView: UITextView!
    public weak var delegate: MathEvaluation!
    
    var number: String = ""
    var symbol: Character = "A"
    
    public override func viewDidLoad() {
        super.viewDidLoad()
    }

    public init() {
        super.init(nibName: "CalculatorViewController", bundle: Bundle(for: CalculatorViewController.self))
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @IBAction func button1Pressed(_ sender: Any) {
        number.append("1")
        displayView.text = number
    }
    
    @IBAction func button2Pressed(_ sender: Any) {
        number.append("2")
        displayView.text = number
    }
    
    @IBAction func button3Pressed(_ sender: Any) {
        number.append("3")
        displayView.text = number
    }
    
    @IBAction func button4Pressed(_ sender: Any) {
        number.append("4")
        displayView.text = number
    }
    
    @IBAction func button5Pressed(_ sender: Any) {
        number.append("5")
        displayView.text = number
    }
    
    @IBAction func button6Pressed(_ sender: Any) {
        number.append("6")
        displayView.text = number
    }
    
    @IBAction func button7Pressed(_ sender: Any) {
        number.append("7")
        displayView.text = number
    }
    
    @IBAction func button8Pressed(_ sender: Any) {
        number.append("8")
        displayView.text = number
    }
    
    @IBAction func button9Pressed(_ sender: Any) {
        number.append("9")
        displayView.text = number
    }
    
    @IBAction func button0Pressed(_ sender: Any) {
        number.append("0")
        displayView.text = number
    }
    
    @IBAction func buttonSinPressed(_ sender: Any) {
        if let value = delegate.evaluateTrigFunction(number: number, symbol:symbol, trigSymbol: .Sin) {
            number = value
            displayView.text = value
        }
    }
    
    @IBAction func buttonTanPressed(_ sender: Any) {
        if let value = delegate.evaluateTrigFunction(number: number, symbol:symbol, trigSymbol: .Tan) {
            number = value
            displayView.text = value
        }
    }
    
    @IBAction func buttonCosPressed(_ sender: Any) {
        if let value = delegate.evaluateTrigFunction(number: number, symbol:symbol, trigSymbol: .Cos) {
            number = value
            displayView.text = value
        }
    }
    
    @IBAction func buttonSquarePressed(_ sender: Any) {
        if let value = delegate.evaluateTwoDFunction(number: number, symbol:symbol, twoDSymbol: .Square) {
            number = value
            displayView.text = value
        }
    }
    
    @IBAction func buttonRootPressed(_ sender: Any) {
        if let value = delegate.evaluateTwoDFunction(number: number, symbol:symbol, twoDSymbol: .Root) {
            number = value
            displayView.text = value
        }
    }
    
    @IBAction func buttonLogPressed(_ sender: Any) {
        if let value = delegate.evaluateTwoDFunction(number: number, symbol:symbol, twoDSymbol: .Log) {
            number = value
            displayView.text = value
        }
    }
    
    @IBAction func buttonReversePressed(_ sender: Any) {
        if let value = delegate.evaluateTwoDFunction(number: number, symbol:symbol, twoDSymbol: .Reverse) {
            number = value
            displayView.text = value
        }
    }
    
    @IBAction func buttonPlusPressed(_ sender: Any) {
        if let value = delegate.evaluateSimpleMathFunction(number: number, symbol: symbol) {
            number = value
        }
        symbol = "+"
        number.append("+")
        displayView.text = number
    }
    
    @IBAction func buttonMinusPressed(_ sender: Any) {
        if let value = delegate.evaluateSimpleMathFunction(number: number, symbol: symbol) {
            number = value
        }
        
        if number.count > 0 {
            symbol = "-"
        }
        number.append("-")
        displayView.text = number
    }
    
    @IBAction func buttonMultiplyPressed(_ sender: Any) {
        if let value = delegate.evaluateSimpleMathFunction(number: number, symbol: symbol) {
            number = value
        }
        symbol = "*"
        number.append("*")
        displayView.text = number
    }
    
    @IBAction func buttonDividePressed(_ sender: Any) {
        if let value = delegate.evaluateSimpleMathFunction(number: number, symbol: symbol) {
            number = value
        }
        symbol = "/"
        number.append("/")
        displayView.text = number
    }
    
    @IBAction func buttonClearPressed(_ sender: Any) {
        number = ""
        displayView.text = ""
        symbol = "A"
    }
    
    @IBAction func buttonLogePressed(_ sender: Any) {
        if let value = delegate.evaluateTwoDFunction(number: number, symbol:symbol, twoDSymbol: .Loge) {
            number = value
            displayView.text = value
        }
    }
    
    @IBAction func resultButtonPressed(_ sender: Any) {
        if let value = delegate.evaluateSimpleMathFunction(number: number, symbol: symbol) {
            number = value
            displayView.text = number
        }
    }
}
