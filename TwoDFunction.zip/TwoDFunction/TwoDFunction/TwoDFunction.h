//
//  TwoDFunction.h
//  TwoDFunction
//
//  Created by vijay singh on 7/13/21.
//

#import <Foundation/Foundation.h>

//! Project version number for TwoDFunction.
FOUNDATION_EXPORT double TwoDFunctionVersionNumber;

//! Project version string for TwoDFunction.
FOUNDATION_EXPORT const unsigned char TwoDFunctionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TwoDFunction/PublicHeader.h>


