//
//  TwoDFunction.swift
//  TwoDFunction
//
//  Created by vijay singh on 7/13/21.
//

import Foundation

public struct TwoDFunction {
    
    public init() {
        
    }
    
    public func square(_ num: Double) -> Double {
        return num*num
    }

    public func reverse(_ num: Double) -> Double {
        return 1.0/num
    }

    public func root(_ num: Double) -> Double {
        return sqrt(num)
    }
    
    public func logarithm(_ num: Double) -> Double {
        return log(num)/log(10)
    }
    
    public func loge(_ num: Double) -> Double {
        return log(num)
    }
}
