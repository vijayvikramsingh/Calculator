//
//  SimpleCalculation.swift
//  SimpleCalculation
//
//  Created by vijay singh on 7/13/21.
//

import Foundation

public struct SimpleCalculation {
    
    public init() {
    }
    
    public func add(_ num1: Double, _ num2: Double) -> Double {
        return num1 + num2
    }

    public func substract(_ num1: Double, _ num2: Double) -> Double {
        return num1 - num2
    }

    public func multiply(_ num1: Double, _ num2: Double) -> Double {
        return num1 * num2
    }

    public func divide(_ num1: Double, _ num2: Double) -> Double {
        return num1 / num2
    }
}
