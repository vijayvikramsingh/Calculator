//
//  SimpleCalculation.h
//  SimpleCalculation
//
//  Created by vijay singh on 7/13/21.
//

#import <Foundation/Foundation.h>

//! Project version number for SimpleCalculation.
FOUNDATION_EXPORT double SimpleCalculationVersionNumber;

//! Project version string for SimpleCalculation.
FOUNDATION_EXPORT const unsigned char SimpleCalculationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SimpleCalculation/PublicHeader.h>


