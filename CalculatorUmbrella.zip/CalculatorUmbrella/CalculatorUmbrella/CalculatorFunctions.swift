//
//  CalculatorFunctions.swift
//  CalculatorUmbrella
//
//  Created by vijay singh on 7/14/21.
//

import Foundation
@_implementationOnly import SimpleCalculation
@_implementationOnly import TrigFuncCalculation
@_implementationOnly import TwoDFunction

public struct CalculatorFunctions {

    public init() {
        
    }
    
    public func signFunc(_ num: Double) -> Double {
        return TrigFuncCalculation().signFunc(num)
    }

    public func cosFunc(_ num: Double) -> Double {
        return TrigFuncCalculation().cosFunc(num)
    }

    public func tanFunc(_ num: Double) -> Double {
        return TrigFuncCalculation().tanFunc(num)
    }

    public func square(_ num: Double) -> Double {
        return TwoDFunction().square(num)
    }

    public func reverse(_ num: Double) -> Double {
        return TwoDFunction().reverse(num)
    }

    public func root(_ num: Double) -> Double {
        return TwoDFunction().root(num)
    }
    
    public func logarithm(_ num: Double) -> Double {
        return TwoDFunction().logarithm(num)
    }
    
    public func loge(_ num: Double) -> Double {
        return TwoDFunction().loge(num)
    }
    
    public func add(_ num1: Double, _ num2: Double) -> Double {
        return SimpleCalculation().add(num1, num2)
    }

    public func substract(_ num1: Double, _ num2: Double) -> Double {
        return SimpleCalculation().substract(num1, num2)
    }

    public func multiply(_ num1: Double, _ num2: Double) -> Double {
        return SimpleCalculation().multiply(num1, num2)
    }

    public func divide(_ num1: Double, _ num2: Double) -> Double {
        return SimpleCalculation().divide(num1, num2)
    }
}
